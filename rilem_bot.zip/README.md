# Bot Rilem/Miler — HeavenCloud

Bot de Discord extraído do Google Colab e adaptado para rodar como **serviço contínuo** em VPS/HeavenCloud.

## Funcionalidades

| Módulo | Comandos |
|--------|----------|
| 🎵 **Música** | `!play`, `!skip`, `!pause`, `!resume`, `!queue`, `!join`, `!leave`, `!loop` |
| 🤖 **RPG IA** | `!rpg_start`, `!rpg_stop` (mencione o bot para interagir) |
| 🎲 **Dados** | `!roll 4d6`, `!roll d20!`, `!roll 4d6d1`, `!roll 6#4d6d1` |
| 💬 **Chat** | `ping`, `oi`, `ajuda` |

---

## Pré-requisitos no servidor

```bash
# Python 3.10+
python3 --version

# FFmpeg (necessário para música)
sudo apt install -y ffmpeg
```

---

## Instalação no HeavenCloud

```bash
# 1. Clone ou envie os arquivos para o servidor
scp -r ./rilem usuario@seu-servidor:~/rilem

# 2. Entre na pasta
cd ~/rilem

# 3. Crie e ative o virtualenv
python3 -m venv venv
source venv/bin/activate

# 4. Instale as dependências
pip install -r requirements.txt
```

---

## Configuração

```bash
# Copie o exemplo e preencha com seus tokens reais
cp .env.example .env
nano .env
```

Variáveis obrigatórias no `.env`:

```
DISCORD_TOKEN=seu_token_aqui
GOOGLE_API_KEY=sua_chave_gemini_aqui   # opcional
```

> **Dica cookies.txt:** Para evitar bloqueios do YouTube coloque o arquivo
> `cookies.txt` na raiz do projeto. Use a extensão
> [Get cookies.txt LOCALLY](https://chromewebstore.google.com/detail/get-cookiestxt-locally/cclelndahbckbenkjhflpdbgdldlbecc)
> logado na sua conta Google.

---

## Rodar manualmente (teste)

```bash
source venv/bin/activate
python bot.py
```

---

## Rodar como serviço (produção)

```bash
# 1. Edite o arquivo .service com o caminho correto
nano rilem-bot.service

# 2. Copie para o systemd
sudo cp rilem-bot.service /etc/systemd/system/

# 3. Recarregue e ative
sudo systemctl daemon-reload
sudo systemctl enable rilem-bot
sudo systemctl start rilem-bot

# 4. Verifique o status
sudo systemctl status rilem-bot

# Ver logs em tempo real
sudo journalctl -u rilem-bot -f
```

---

## Diferenças em relação ao Colab

| Colab | HeavenCloud |
|-------|-------------|
| `from google.colab import userdata` | `python-dotenv` + arquivo `.env` |
| `nest_asyncio.apply()` | Removido (não necessário) |
| `cookiefile: /content/cookies.txt` | `./cookies.txt` (pasta do projeto) |
| `bot.run()` dentro do notebook | `if __name__ == "__main__": bot.run(...)` |
| Desliga após inatividade do Colab | Systemd reinicia automaticamente em falhas |
